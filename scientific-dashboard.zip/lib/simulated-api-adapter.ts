import { simulatedBackend } from "@/lib/simulated-backend"
import type { Sample } from "@/types/sample"
import type { Measurement } from "@/types/measurement"
import type { MBERecipe } from "@/types/mbe-recipe"
import { db } from "@/lib/simulated-db"

// This adapter translates between our API client and the simulated backend
// In a real application, this would be replaced with actual API calls

// Samples API
export async function fetchSamples(): Promise<Sample[]> {
  try {
    return await simulatedBackend.getSamples()
  } catch (error) {
    throw error
  }
}

export async function fetchSampleById(id: string): Promise<Sample> {
  try {
    const sample = await simulatedBackend.getSample(id)
    if (!sample) {
      throw new Error(`Sample with ID ${id} not found`)
    }
    return sample
  } catch (error) {
    throw error
  }
}

export async function createSampleApi(sample: Omit<Sample, "id" | "createdAt">): Promise<Sample> {
  try {
    const response = await simulatedBackend.post("/samples", sample)
    return response.data
  } catch (error) {
    throw error
  }
}

export async function updateSampleApi(id: string, sample: Partial<Sample>): Promise<Sample> {
  try {
    const response = await simulatedBackend.put(`/samples/${id}`, sample)
    return response.data
  } catch (error) {
    throw error
  }
}

export async function deleteSampleApi(id: string): Promise<void> {
  try {
    await simulatedBackend.delete(`/samples/${id}`)
  } catch (error) {
    throw error
  }
}

// Measurements API
export async function fetchMeasurements(): Promise<Measurement[]> {
  try {
    return await simulatedBackend.getAllMeasurements()
  } catch (error) {
    throw error
  }
}

export async function fetchMeasurementById(id: string): Promise<Measurement> {
  try {
    const measurement = await simulatedBackend.getMeasurementById(id)
    if (!measurement) {
      throw new Error(`Measurement with ID ${id} not found`)
    }
    return measurement
  } catch (error) {
    throw error
  }
}

export async function fetchMeasurementsBySampleId(sampleId: string): Promise<Measurement[]> {
  try {
    return await simulatedBackend.getMeasurementsBySampleId(sampleId)
  } catch (error) {
    throw error
  }
}

export async function createMeasurementApi(measurement: Partial<Measurement>): Promise<Measurement> {
  try {
    const response = await simulatedBackend.post("/measurements", measurement)
    return response.data
  } catch (error) {
    throw error
  }
}

export async function updateMeasurementApi(id: string, measurement: Partial<Measurement>): Promise<Measurement> {
  try {
    const response = await simulatedBackend.put(`/measurements/${id}`, measurement)
    return response.data
  } catch (error) {
    throw error
  }
}

export async function deleteMeasurementApi(id: string): Promise<void> {
  try {
    await simulatedBackend.delete(`/measurements/${id}`)
  } catch (error) {
    throw error
  }
}

// MBE Recipes API
export async function fetchRecipes(): Promise<MBERecipe[]> {
  try {
    const response = await simulatedBackend.get("/mbe-recipes")
    return response.data
  } catch (error) {
    throw error
  }
}

export async function fetchRecipeById(id: string): Promise<MBERecipe> {
  try {
    const response = await simulatedBackend.get(`/mbe-recipes/${id}`)
    return response.data
  } catch (error) {
    throw error
  }
}

export async function fetchRecipeBySampleId(sampleId: string): Promise<MBERecipe | null> {
  try {
    // The URL should be /mbe-recipes/sample/{sampleId}
    const response = await simulatedBackend.get(`/mbe-recipes/sample/${sampleId}`)
    return response.data
  } catch (error) {
    // If the error is a 404, return null instead of throwing
    if (error instanceof Error && error.message.includes("not found")) {
      return null
    }
    throw error
  }
}

export async function createRecipeApi(recipe: Partial<MBERecipe>): Promise<MBERecipe> {
  try {
    const response = await simulatedBackend.post("/mbe-recipes", recipe)
    return response.data
  } catch (error) {
    throw error
  }
}

export async function updateRecipeApi(id: string, recipe: Partial<MBERecipe>): Promise<MBERecipe> {
  try {
    const response = await simulatedBackend.put(`/mbe-recipes/${id}`, recipe)
    return response.data
  } catch (error) {
    throw error
  }
}

export async function deleteRecipeApi(id: string): Promise<void> {
  try {
    await simulatedBackend.delete(`/mbe-recipes/${id}`)
  } catch (error) {
    throw error
  }
}

// File Upload API
export async function uploadFileApi(file: File): Promise<any> {
  try {
    return await simulatedBackend.addFile(file, file.name)
  } catch (error) {
    throw error
  }
}

// Add or update these handler functions in your simulated backend

// Handler for GET /api/samples
export async function handleGetSamples(req) {
  // Get samples from the simulated database
  const samples = await db.samples.getAll()
  return samples
}

// Handler for GET /api/measurements with filter support
export async function handleGetMeasurements(req) {
  // Get the query parameters
  const url = new URL(req.url)
  const sampleId = url.searchParams.get("sampleId")
  const type = url.searchParams.get("type")

  // Get all measurements
  let measurements = await db.measurements.getAll()

  // Apply filters if provided
  if (sampleId) {
    measurements = measurements.filter((m) => m.sampleId === sampleId)
  }

  if (type) {
    measurements = measurements.filter((m) => m.type === type)
  }

  return measurements
}

