"use server"

import { generateSampleData } from "@/lib/sample-data-generator"

// Simulated in-memory database
const initialData = generateSampleData()

export const db = {
  samples: {
    data: initialData.samples,
    async getAll() {
      return this.data
    },
    async get(id: string) {
      return this.data.find((sample) => sample.id === id)
    },
    async create(sample: any) {
      this.data.push(sample)
      return sample
    },
    async update(id: string, updates: any) {
      const index = this.data.findIndex((sample) => sample.id === id)
      if (index !== -1) {
        this.data[index] = { ...this.data[index], ...updates }
        return this.data[index]
      }
      return null
    },
    async delete(id: string) {
      this.data = this.data.filter((sample) => sample.id !== id)
    },
  },
  measurements: {
    data: initialData.measurements,
    async getAll() {
      return this.data
    },
    async get(id: string) {
      return this.data.find((measurement) => measurement.id === id)
    },
    async create(measurement: any) {
      this.data.push(measurement)
      return measurement
    },
    async update(id: string, updates: any) {
      const index = this.data.findIndex((measurement) => measurement.id === id)
      if (index !== -1) {
        this.data[index] = { ...this.data[index], ...updates }
        return this.data[index]
      }
      return null
    },
    async delete(id: string) {
      this.data = this.data.filter((measurement) => measurement.id !== id)
    },
  },
  recipes: {
    data: initialData.mbeRecipes,
    async getAll() {
      return this.data
    },
    async get(id: string) {
      return this.data.find((recipe) => recipe.id === id)
    },
    async create(recipe: any) {
      this.data.push(recipe)
      return recipe
    },
    async update(id: string, updates: any) {
      const index = this.data.findIndex((recipe) => recipe.id === id)
      if (index !== -1) {
        this.data[index] = { ...this.data[index], ...updates }
        return this.data[index]
      }
      return null
    },
    async delete(id: string) {
      this.data = this.data.filter((recipe) => recipe.id !== id)
    },
  },
}

